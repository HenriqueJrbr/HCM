<?php
define('BASE_PATH', $_SERVER['DOCUMENT_ROOT'].'/repo_sga/SGA V2.03/PHP');
define('LOG_PATH', BASE_PATH.'/logs');
define("URL", 'http://'. str_replace('//','/', $_SERVER['HTTP_HOST']).'/repo_sga/SGA V2.03/PHP');

global $config;
global $db;

// $config['dbname'] = 'wwapps_sga_v2.03.1';
// $config['host'] = '162.214.92.26';
// $config['dbuser'] = 'wwapps_root';
// $config['dbpass'] = 'bitistech@2020!';

$config['dbname'] = 'wwapps_sga_v2.03.1';
$config['host'] = 'localhost';
$config['dbuser'] = 'root';
$config['dbpass'] = 'Junior120255';


try{
	$db = new PDO("mysql:dbname=".$config['dbname'].";charset=utf8;host=".$config['host'], $config['dbuser'], $config['dbpass']);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(EXCEPTION $e){
	die($e->getMessage());
}
