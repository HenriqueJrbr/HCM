<?php
class Controller {

	protected $db;
	protected $helper;

	public function __construct() {                
		global $config;
		$this->db = new PDO("mysql:dbname=".$config['dbname'].";charset=utf8;host=".$config['host'], $config['dbuser'], $config['dbpass']);
		$this->helper = new Helper();                 
	}
	
	public function loadView($viewName, $viewData = array()) {
		extract($viewData);

		include 'views/'.$viewName.'.php';
	}

	public function loadTemplate($viewName, $viewData = array()) {	

		$sql = "SELECT * FROM z_sga_empresa";
      	$sql = $this->db->query($sql);

      	$array = array();
      	if($sql->rowCount()>0){
      		$array = $sql->fetchAll();
      	}

 

		include 'views/template.php';
	}

	public function loadViewInTemplate($viewName, $viewData) {
            setlocale(LC_TIME, 'pt_BR');
            date_default_timezone_set('America/Sao_Paulo');
            extract($viewData);

            include 'views/'.$viewName.'.php';
	}

	function gravar($texto){
        //Variável arquivo armazena o nome e extensão do arquivo.
        $arquivo = './arquivos/log.txt';
        
        //Variável $fp armazena a conexão com o arquivo e o tipo de ação.
        $fp = fopen($arquivo, "a+");

        $textoEscrito = '************************************ '.date('d - m - Y').' ****************************************'.PHP_EOL;
        $textoEscrito.=$texto.PHP_EOL;
    
        //Escreve no arquivo aberto.
        fwrite($fp, $textoEscrito);
        
        //Fecha o arquivo.
        fclose($fp);
    }
}
