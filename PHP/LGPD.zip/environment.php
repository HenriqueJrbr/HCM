<?php
define("ENVIRONMENT", "development");
?>