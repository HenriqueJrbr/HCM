<?php
/**
 * Created by Rodrigo Gomes do Nascimento.
 * User: a2
 * Date: 04/01/2019
 * Time: 12:39
 */

class FluxoAgendamento extends Model
{
    public function __construct(){
        parent::__construct();
    }


}