<?php

class Sincronizacao extends Model
{

    public function __construct()
    {
        parent::__construct();
    }

	/**
	* Valida se programa já está cadastrado
	*/
    public function validaCadastroProgramas($codPrograma)
    {                      
        $sql = "
            SELECT 
                z_sga_programas_id,
                cod_programa 
            FROM 
                z_sga_programas
            WHERE 
                cod_programa = '".$codPrograma."'";      
				//echo $sql."<br>";
				//die;
        try{
            $sql = $this->db->query($sql);

            if($sql->rowCount() > 0):

                $sql = $sql->fetch(PDO::FETCH_ASSOC);
                
                return array(
                    'return' => true,
                    'z_sga_programas_id' => $sql['z_sga_programas_id']
                );
            endif;
        }catch (EXCEPTION $e){
            return array(
                'return' => false,
                'error'  => $e->getMessage()
            );
        }
    }
	
	/**
	* Valida se empresa já está relacinado à programa
	*/
    public function validaCadastroProgramasEmpresas($codPrograma, $idEmpresa, $analise)
    {
        $sql = "
            SELECT
                z_sga_programas_id as idPrograma
            FROM
                z_sga_programas
            WHERE
                cod_programa = '".
				//str_replace(['Ã£','Ã§'], ['ã','ç'], utf8_encode($codPrograma))."'"
				$codPrograma."'";
                //echo $sql."<br>";
        try{
            $sql = $this->db->query($sql);

            if($sql->rowCount() > 0):
                $prog = $sql->fetch(PDO::FETCH_ASSOC);

                $sql = "
                    SELECT
                        idGrupoPrograma,
                        idPrograma
                    FROM 
                        z_sga_programa_empresa
                    WHERE 
                        idPrograma = ".$prog['idPrograma']."
                        AND idEmpresa = $idEmpresa";
                //echo $sql."<br>";
                $sql = $this->db->query($sql);

                if($sql->rowCount()> 0):
                    $sql = $sql->fetch(PDO::FETCH_ASSOC);

                    return array('return' => true, 'idGrupoPrograma' => $sql['idGrupoPrograma']);
                else:
                    return array(
                        'return' => false,
                        'idPrograma' => $prog['idPrograma']
                    );
                endif;
            else:
                if($analise == 1):
                    return array(
                        'return' => false,
                        'error'  => $codPrograma
                    );
                else:
                    return array(
                        'return' => 'error',
                        'error'  => 'Alguns registros não foram encontrados. Favor sincronizar os programas.'
                    );
                endif;
                
            endif;
        }catch (EXCEPTION $e){
            return array(
                'return' => false,
                'error'  => $e->getMessage()
            );
        }

    }
	
	/**
	* Valida se grupo já está relacinado à programa
	*/
    public function validaCadastroGruposProgramas($codGrupo, $codPrograma, $analise, $instancia)
    {
        $sql = "
            SELECT
                z_sga_grupo_programa_id,
				cod_grupo,
                cod_programa,
                nome_grupo
            FROM 
                z_sga_grupo_programa
            WHERE 
				cod_grupo = '".$codGrupo."'
                AND cod_programa = '".$codPrograma."'
                AND idEmpresa = " . $instancia;

        try{
            $sql = $this->db->query($sql);

            if($sql->rowCount() > 0):
                $sql = $sql->fetch(PDO::FETCH_ASSOC);

                return array(
                    'return' => true,
                    'z_sga_grupo_programa_id' => $sql['z_sga_grupo_programa_id']
                );
            else:
                $sql = "
                    SELECT 
                        idGrupo,
                        idLegGrupo,
                        descAbrev,
                        '' AS gestor
                    FROM 
                        z_sga_grupo	 
                    WHERE 
                        idLegGrupo = '".$codGrupo."'";
                $sql = $this->db->query($sql);

                if($sql->rowCount() == 0):
                    if($analise == 0):
						return ['return' => true];
                        //return array(
                        //    'return' => 'error',
                        //    'error'  => 'Alguns registros não foram encontrados. Favor sincronizar os programas e grupos novamente.'
                        //);
                    endif;
                    
                endif;

                $grupo = $sql->fetch(PDO::FETCH_ASSOC);

                $sql = "
                    SELECT 
                        z_sga_programas_id AS idPrograma, 
                        cod_programa 
                    FROM 
                        z_sga_programas 
                    WHERE cod_programa = '".$codPrograma."'";

                $sql = $this->db->query($sql);

                if($sql->rowCount() == 0):
                    if($analise == 0):
						return ['return' => true];
                        //return array(
                        //    'return' => 'error',
                        //    'error'  => 'Alguns registros não foram encontrados. Favor sincronizar os <strong>programas</strong> novamente.'
                        //);
                    endif;
                else:
                    $prog = $sql->fetch(PDO::FETCH_ASSOC);

                    return array(
                        'return'        => false,
                        'idGrupo'       => $grupo['idGrupo'],
                        'codGrupo'      => $grupo['idLegGrupo'],
                        'nomeGrupo'     => $grupo['descAbrev'],
                        'gestor'        => $grupo['gestor'],
                        'idPrograma'    => $prog['idPrograma'],
                        'codPrograma'  => $prog['cod_programa']
                    );
                endif;
            endif;
        }catch (EXCEPTION $e){
            return array(
                'return' => false,
                'error'  => $e->getMessage()
            );
        }

    }
	
	/**
	* Valida se grupo já está relacinado à usuário
	*/
    public function validaCadastroGruposUsuarios($codGrupo, $codUsuario, $analise)
    {
        $sql = "
            SELECT
                z_sga_grupos_id,
				cod_grupo
            FROM 
                z_sga_grupos
            WHERE 
				cod_grupo = '".$codGrupo."'
                AND cod_usuario = '".$codUsuario."'";
		
        try{
            $sql = $this->db->query($sql);

            if($sql->rowCount() > 0):
                $sql = $sql->fetch(PDO::FETCH_ASSOC);

                return array(
                    'return' => true,
                    'z_sga_grupos_id' => $sql['z_sga_grupos_id']
                );
            else:
                $sql = "
                    SELECT 
                        idGrupo,
                        idLegGrupo,
                        descAbrev,
                        '' AS 'gestor'		
                    FROM 
                        z_sga_grupo	 
                    WHERE 
                        idLegGrupo = '".$codGrupo."'";
			//echo $sql."<br>";
                $sql = $this->db->query($sql);

                if($sql->rowCount() == 0):
                    if($analise == 0):
                        return array(
                            'return' => 'error',
                            'error'  => 'Alguns registros não foram encontrados. Favor sincronizar os usuários e grupos novamente.'
                        );
                    else:
                        return ['return' => false];
                    endif;
                endif;

                $grupo = $sql->fetch(PDO::FETCH_ASSOC);

                $sql = "
                    SELECT 
                        z_sga_usuarios_id AS idUsuario, 
                        cod_usuario 
                    FROM 
                        z_sga_usuarios 
                    WHERE cod_usuario = '".$codUsuario."'";
				//echo $sql."<br>";
                $sql = $this->db->query($sql);

                if($sql->rowCount() == 0):
                    if($analise == 0):
                        return array(
                            'return' => 'error',
                            'error'  => 'Alguns registros não foram encontrados. Favor sincronizar os <strong>usuários</strong> e <strong>grupos</strong> novamente.'
                        );
                    else:
                        return ['return' => false];
                    endif;
                endif;

                $prog = $sql->fetch(PDO::FETCH_ASSOC);
                return array(
                    'return'        => false,
                    'idGrupo'       => $grupo['idGrupo'],
                    'codGrupo'      => $grupo['idLegGrupo'],
                    'nomeGrupo'     => $grupo['descAbrev'],
                    'gestor'        => $grupo['gestor'],
                    'idUsuario'    => $prog['idUsuario'],
                    'codUsuario'  => $prog['cod_usuario']
                );
            endif;
        }catch (EXCEPTION $e){
            return array(
                'return' => false,
                'error'  => $e->getMessage()
            );
        }

    }

	/**
	* Valida se grupo já está cadastrado
	*/
    public function validaCadastroGrupos($idLegGrupo)
    {
        $sql = "
            SELECT 
                idGrupo, 
                idLegGrupo
            FROM 
                z_sga_grupo
            WHERE 
                idLegGrupo = '".$idLegGrupo."'";
        try{
            $sql = $this->db->query($sql);

            if($sql->rowCount() > 0):
                $sql = $sql->fetch(PDO::FETCH_ASSOC);

                return array(
                    'return' => true,
                    'idGrupo' => $sql['idGrupo']
                );
            endif;
        }catch (EXCEPTION $e){
            return array(
                'return' => false,
                'error'  => $e->getMessage()
            );
        }
    }
	
	/**
	* Valida se usuário já está cadastrado
	*/
    public function validaCadastroUsuarios($codUsuario)
    {
        $sql = "
            SELECT 
                z_sga_usuarios_id,
                cod_usuario
            FROM 
                z_sga_usuarios
            WHERE 
                cod_usuario = '".$codUsuario."'";
        try{
            $sql = $this->db->query($sql);

            if($sql->rowCount() > 0):
                $sql = $sql->fetch(PDO::FETCH_ASSOC);

                return array(
                    'return' => true,
                    'z_sga_usuarios_id' => $sql['z_sga_usuarios_id']
                );
            endif;
        }catch (EXCEPTION $e){
            return array(
                'return' => false,
                'error'  => $e->getMessage()
            );
        }
    }
	
	/**
	* Valida se usuário já está cadastrado para instancia informada
	*/
    public function validaCadastroUsuariosEmpresas($codUsuario, $idEmpresa, $analise)
    {
        $sql = "
            SELECT 
                z_sga_usuarios_id AS idUsuario,
                ativo
            FROM 
                z_sga_usuarios
            WHERE 
                cod_usuario = '".$codUsuario."'";
        try{
            $sql = $this->db->query($sql);

            if($sql->rowCount() > 0):
                $usr = $sql->fetch(PDO::FETCH_ASSOC);

                $sql = "
                    SELECT 
                        idUsrEMp,
                        idUsuario
                    FROM 
                        z_sga_usuario_empresa
                    WHERE 
                        idUsuario = ".$usr['idUsuario']."
                        AND idEmpresa = $idEmpresa";

                $sql = $this->db->query($sql);
                if($sql->rowCount() > 0):
                    $sql = $sql->fetch(PDO::FETCH_ASSOC);
                    return array('return' => true, 'idUsrEMp' => $sql['idUsrEMp']);
                else:
                    return array(
                        'return' => false,
                        'idUsuario' => $usr['idUsuario'],
                        'codUsuario' => $codUsuario,
                        'ativo'     => $usr['ativo']
                    );
                endif;
            else:
                if($analise == 0):
                    return array(
                        'return' => 'error',
                        'error'  => 'Alguns registros não foram encontrados. Favor sincronizar os programas.'
                    );
                else:
                    return ['return' => false];
                endif;
            endif;
        }catch (EXCEPTION $e){
            return array(
                'return' => false,
                'error'  => $e->getMessage()
            );
        }
    }

    /**
	* Valida se função já está cadastrada
	*/
    public function validaCadastroFuncao($codFuncao)
    {                      
        $sql = "
            SELECT 
                cod_funcao 
            FROM 
                z_sga_manut_funcao
            WHERE 
                cod_funcao = '".$codFuncao."'";      
				//echo $sql."<br>";
				//die;
        try{
            $sql = $this->db->query($sql);

            if($sql->rowCount() > 0):
                return array(
                    'return' => true
                );
            endif;
        }catch (EXCEPTION $e){
            return array(
                'return' => false,
                'error'  => $e->getMessage()
            );
        }
    }

    /**
	* retorna dadados da tabela z_sga_grupo_programa
	*/
    public function getGruposProgramas($codGrupo, $codPrograma)
    {
        $sql = "
            SELECT
                gp.z_sga_grupo_programa_id,
                g.descAbrev
            FROM 
                z_sga_grupo_programa gp
            LEFT JOIN
                z_sga_grupo g
                ON g.idGrupo = gp.idGrupo
            WHERE 
				(gp.cod_grupo = '".$codGrupo."'
                AND gp.cod_programa = '".$codPrograma."')
                AND g.idEmpresa = " . $_SESSION['empresaid'];
               // echo $sql."<br>";
        try{
            $sql = $this->db->query($sql);

            if($sql->rowCount() > 0):
                return [
                    'return'    => true,
                    'dados'     => $sql->fetch(PDO::FETCH_ASSOC)
                    //'dados'     => $sql->fetchAll(PDO::FETCH_ASSOC)
                ];
            else:
                return [
                    'return' => true,
                    'dados'  => []
                ];
            endif;
        }catch(EXCEPTION $e){
            return [];
        }
    }

    /**
	* retorna dadados da tabela z_sga_grupos
	*/
    public function getGruposUsuarios($codGrupo, $codUsuario)
    {
        $sql = "
            SELECT
                z_sga_grupos_id AS idGruposId
            FROM 
                z_sga_grupos gs
            LEFT JOIN
                z_sga_grupo g
                ON g.idGrupo = gs.idGrupo
            WHERE 
				(cod_grupo = '".$codGrupo."'
                AND cod_usuario = '".$codUsuario."')
                ANd g.idEmpresa = " . $_SESSION['empresaid'];
        try{
            $sql = $this->db->query($sql);

            if($sql->rowCount() > 0):
                return [
                    'return'    => true,
                    'dados'     => $sql->fetchAll(PDO::FETCH_ASSOC)
                ];
            else:
                return [
                    'return' => true,
                    'dados'  => []
                ];
            endif;
        }catch(EXCEPTION $e){
            return [];
        }
    }

	/**
	* Retorna os registros que estão a mais no SGA
	* @param $query
	*/
	public function comparaDiffSGA($query)
	{
        //echo $query."<br><br>";
		$res = $this->db->query($query);
		//echo ($res->rowCount());
		if($res->rowCount() > 0):
			return $res->fetchAll(PDO::FETCH_ASSOC);
		else:
			return [];
		endif;
	}

	/**
	* Realiza sincronizacao. Utiliza query criada e atribuida em sessão.
	*/

    public function sincronizaDados($query, $table, $nameFileBkp, $query_diff_sga)
    {
        $bkp = false;
        $diffSga = [];
        
		try{
            // Faz backup da tabela
            if(!empty($query)):                
                $bkp = $this->backup_tables($table, $nameFileBkp);

                if($bkp):       
                    if(!empty($quer)):         
                        $res = $this->db->query($query);
                    endif;
                else:
                    return array(
                        'return'    => false,
                        'error'     => 'Erro ao fazer backup'
                    );            
                endif;
            endif; 

            
                        
            // Executa comparação de registros a mais no SGA
            if(!empty($query_diff_sga)):                
                //echo($query_diff_sga)."<br>";


                if($table == 'z_sga_grupos' || $table == 'z_sga_grupo_programa'):
                    if($bkp == false):
                        $bkp = $this->backup_tables($table, $nameFileBkp);
                    endif;

                    if($bkp):                                                
                        try{
                            $res = $this->db->query(str_replace('SELECT *', 'DELETE ', $query_diff_sga));
                            //print_r($res);
                        }catch(EXCEPTION $e){
                            //print_r($e);
                            die($e->getMessage());
                        }
                        
                    else:
                        return array(
                            'return'    => false,
                            'error'     => 'Erro ao fazer backup'
                        );
                    endif;                
                endif;

                $diffSga = $this->db->query($query_diff_sga);
                if($diffSga->rowCount() > 0):
                    // Faz backup se ainda não fez
                    if($bkp == false):
                        $bkp = $this->backup_tables($table, $nameFileBkp);
                    endif;

                    if($bkp):
                        $diffSga = $diffSga->fetchAll(PDO::FETCH_ASSOC);
                        //echo(str_replace('SELECT *', 'DELETE ', $query_diff_sga))."<br>";
                        try{
                            $res = $this->db->query(str_replace('SELECT *', 'DELETE ', $query_diff_sga));
                            //print_r($res);
                        }catch(EXCEPTION $e){
                            print_r($e);
                            die($e->getMessage());
                        }
                        
                    else:
                        return array(
                            'return'    => false,
                            'error'     => 'Erro ao fazer backup'
                        );
                    endif;
                else:
                    $diffSga = [];
                endif;
            endif;

            return array(
                'return'        => true,
                //'rowCount'      => $res->rowCount(),
                'diffSga'       => $diffSga
            );            			
		}catch(EXCEPTION $e){
            die($e->getMessage());
			return array(
				'return' => false,
				'error'	 => "Erro de sincronização! <br>". $e->getMessage() . "<br>Favor tentar novamente."
			);
		}		        
    }   


	/**
	* backup the db OR just a table 
	*/
	public function backup_tables($tables = '*', $nameFileBkp)
	{				
		try{
			$return = '';
			//get all of the tables
			if($tables == '*'):		
				$tables = array();
				$result = $this->db->query('SHOW TABLES')->fetchAll(PDO::FETCH_ASSOC);
				
				foreach($result as $val):			
					$tables[] = $val;
				endforeach;
			else:		
				$tables = is_array($tables) ? $tables : explode(',',$tables);
			endif;
            
            //save file
			$nome_backup = $nameFileBkp;

			//cycle through
			foreach($tables as $table):	
				$result = $this->db->query('SELECT * FROM ' . $table);
				$num_fields = $result->columnCount();
				$result = $result->fetchAll(PDO::FETCH_ASSOC);							
				
				$return .= 'DROP TABLE '.$table.';';
				$create_table = $this->db->query('SHOW CREATE TABLE '.$table)->fetch(PDO::FETCH_ASSOC);
				$return .= "\n\n".$create_table['Create Table'].";\n\n";																											
				$return.= 'INSERT INTO '.$table.' VALUES ';				
				foreach($result as $res):
					$return .= '(';
					foreach($res as $val):
						$return .= "'".addslashes($val)."', ";						
					endforeach;					
					$return = substr(trim($return), 0, -1);
					$return.= "),\n";				
				endforeach;				
				$return = substr(trim($return), 0, -1);
                $return .= ";\n\n\n";
                //echo $return."<br>";
			endforeach;
			
			//echo "<pre>";
			//print_r($return);
			//die;
			
			setlocale(LC_TIME, 'pt_BR');
			date_default_timezone_set('America/Sao_Paulo');
									
			$handle = fopen(BASE_PATH.'/dumps/'.$nome_backup, 'a+');
			fwrite($handle, $return);
			fclose($handle);
		
			return array(
				'return'	=> true				
			);
		}catch(EXCEPTION $e){
			return array(
				'return' => false,
				'error'	 => $e->getMessage()
			);
		}
	}

	/**
     * Grava log das sincronizações
     * @param $data
     * @return array
     */
	public function gravaHistoricoSincronizacao($programas, $progEmpresa, $usuarios, $usuarioEmpresa, $grupos, $gruposUsuarios, $gruposProgramas, $funcao, $instancia, $anexo, $backupFile, $fileDiff, $inicio, $status)
    {		

		setlocale(LC_TIME, 'pt_BR');
        date_default_timezone_set('America/Sao_Paulo');
        $idUsuario = '';
        
        if(!isset($_SESSION['idUsrTotvs'])):
            $sql = $this->db->query("SELECT z_sga_usuarios_id AS idUsuario FROM z_sga_usuarios WHERE cod_usuario = 'super'");
            //echo $sql."<br>";
            if($sql->rowCount() > 0):
                $sql = $sql->fetch(PDO::FETCH_ASSOC);
                $idUsuario = $sql['idUsuario'];
            endif;
        else:
            $idUsuario = $_SESSION['idUsrTotvs'];
        endif;
        
		try{
			$sql = "
				INSERT INTO
					z_sga_sincronizacao(
						`idUsuario`,
                        `progs`,
                        `progsDel`,
                        `progEmp`,
                        `progEmpDel`,
                        `users`,
                        `usersDel`,
                        `userEmp`,
                        `userEmpDel`,
                        `grupos`,
                        `gruposDel`,
                        `grupoUser`,
                        `grupoUserDel`,
                        `grupoProg`,
                        `grupoProgDel`,
                        `funcao`,
                        `funcaoDel`,
                        `instancia`,
                        `anexo`,
                        `dump`,
                        `csvResult`,
                        `inicio`,
                        `fim`,
                        `data`,
                        `status`
					) VALUES(
						$idUsuario,
                        {$programas['totNaoCadastrados']},
                        {$programas['totEliminados']},
                        {$progEmpresa['totNaoCadastrados']},
                        {$progEmpresa['totEliminados']},
                        {$usuarios['totNaoCadastrados']},
                        {$usuarios['totEliminados']},  
                        {$usuarioEmpresa['totNaoCadastrados']},
                        {$usuarioEmpresa['totEliminados']},
                        {$grupos['totNaoCadastrados']},
                        {$grupos['totEliminados']},
                        {$gruposUsuarios['totNaoCadastrados']},
                        {$gruposUsuarios['totEliminados']}, 
                        {$gruposProgramas['totNaoCadastrados']},
                        {$gruposProgramas['totEliminados']},                     
                        {$funcao['totNaoCadastrados']},
                        {$funcao['totEliminados']},   
                        {$instancia},
                        '{$anexo}',
                        '{$backupFile}',
                        '{$fileDiff}',
                        '{$inicio}',
                        '".date('Y-m-d H:i:s')."',
                        '".date('Y-m-d H:i:s')."',
                        '{$status}'
					)
			";
            //echo "<pre>";
            //echo $sql;
            //die;
			$this->db->query($sql);
            
			return array('return' => true);
		}catch(EXCEPTION $e){			
			return array(
				'return' => false,
				'error'	 => $e->getMessage()
			);
		}		       
    }

    public function gravaHistoricoSincronizacaoGestores($idUsuario, $totalCad, $totalNotCad, $anexo, $bkp, $inicio)
    {
        try {
            // die('w2');
            $sql = "
                INSERT INTO
                    z_sga_sincronizacao_gestores (
                        `idUsuario`,
                        `atualizado`,
                        `erro`,
                        `anexo`,
                        `dump`,
                        `inicio`,
                        `fim`,
                        `data`
                    ) VALUES (
                        $idUsuario,
                        {$totalCad},
                        {$totalNotCad},
                        '{$anexo}',
                        '{$bkp}',
                        '{$inicio}',
                        '" . date('Y-m-d H:i:s') . "',
                        '" . date('Y-m-d H:i:s') . "'
                    )
            ";

            // die($sql);
            $this->db->query($sql);
        } catch (Exception $e) {
            return array(
                'return' => false,
                'error'  => $e->getMessage()
            );
        }
    }

    /**
     * Busca os atividades dos fluxos do sistema
     */
    public function carregaLogs()
    {
        $sql = "
            SELECT                 
                l.*,
                u.nome_usuario                
            FROM 
                z_sga_sincronizacao l
			INNER JOIN
				z_sga_usuarios u
				ON l.idUsuario = u.z_sga_usuarios_id			
        ";        
        
        $sql = $this->db->query($sql);

        $dados = array();
        if ($sql->rowCount() > 0):
            $dados = $sql->fetchAll(PDO::FETCH_ASSOC);
        endif;

        return $dados;
    }

    public function carregaLogsGestores()
    {
        $sql = "
            SELECT                 
                l.*,
                u.nome_usuario                
            FROM 
                z_sga_sincronizacao_gestores l
            INNER JOIN
                z_sga_usuarios u
                ON l.idUsuario = u.z_sga_usuarios_id            
        ";        
        
        $sql = $this->db->query($sql);

        $dados = array();
        if (!empty($sql) && $sql->rowCount() > 0):
            $dados = $sql->fetchAll(PDO::FETCH_ASSOC);
        endif;

        return $dados;
    }

    public function validaCadastroGestorUsuario($codUser, $codGestor)
    {
        // Variaveis
        $select = "";
        $update = "";
        $delete = "";
        $gestorOld = 0;
        $hasGestor = 0;
        $idUsuario = 0;
        $idGestor = 0;
        $selectRes = array();

        /* --------------------- Inicio da sessão --------------------- */
        // Verifica se o usuario e o gestor não são iguais
        if ($codGestor == $codUser) {
            return array('return' => false);
        }
        /* --------------------- Fim da sessão --------------------- */

        /* --------------------- Inicio da sessão --------------------- */
        // Checa se o usuario existe
        $select = "
            SELECT
                z_sga_usuarios_id
            FROM
                z_sga_usuarios
            WHERE
                cod_usuario = '$codUser'
        ";

        // die($select);

        // Tenta executar o select
        try {
            $select = $this->db->query($select);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }

        if ($select->rowCount() > 0) {
            $selectRes = $select->fetch(PDO::FETCH_ASSOC);

            // die(print_r($selectRes));

            $idUsuario = $selectRes['z_sga_usuarios_id'];
        } else {
            return array('return' => false);
        }
        /* --------------------- Fim da sessão --------------------- */

        /* --------------------- Inicio da sessão --------------------- */
        // Checa se o gestor existe
        $select = "
            SELECT 
                z_sga_usuarios_id
            FROM
                z_sga_usuarios
            WHERE
                cod_usuario = '$codGestor'
        ";

        // die($select);

        // Tenta executar o select
        try {
            $select = $this->db->query($select);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }

        // Trata os resultados
        if ($select->rowCount() > 0) {
            $selectRes = $select->fetch(PDO::FETCH_ASSOC);

            $idGestor = $selectRes['z_sga_usuarios_id'];
        } else {
            return array('return' => false);
        }
        /* --------------------- Fim da sessão --------------------- */

        /* --------------------- Inicio da sessão --------------------- */
        // Query's
        $update = "UPDATE z_sga_usuarios SET cod_gestor = '$codGestor' WHERE cod_usuario = '$codUser'";
        $delete = "DELETE FROM z_sga_gestor_usuario WHERE idUsuario = $idUsuario";
        $insert = "INSERT INTO z_sga_gestor_usuario (idGestor, idUsuario) VALUES ($idGestor, $idUsuario)";

        // Executa as querys
        try {
            $this->db->query($update);
            $this->db->query($delete);
            $this->db->query($insert);

            return array('return' => true);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }
        /* --------------------- Fim da sessão --------------------- */
    }

    public function validaCadastroGestorPrograma($codGestor, $codPrograma)
    {
        // Variaveis
        $select = "";
        $insert = "";
        $delete = "";
        $codRotina = "";
        $codModulo = "";
        $idGestor = 0;
        $selectRes = array();

        // Checa se o programa existe e retorna o codigo da rotina e do modulo
        $select = "
            SELECT
                cod_modulo,
                codigo_rotina as cod_rotina
            FROM
                z_sga_programas
            WHERE
                cod_programa = '$codPrograma'
        ";

        // die($select);

        // Tenta executar o select
        try {
            $select = $this->db->query($select);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }

        if ($select->rowCount() > 0) {
            $selectRes = $select->fetch(PDO::FETCH_ASSOC);

            $codModulo = $selectRes['cod_modulo'];
            $codRotina = $selectRes['cod_rotina'];
        } else {
            return array('reutrn' => false);
        }


        // Checa se o gestor existe e retorna o id dele
        $select = "
            SELECT
                z_sga_usuarios_id
            FROM 
                z_sga_usuarios
            WHERE
                cod_usuario = '$codGestor'
        ";

        // Tenta executar o select
        try {
            $select = $this->db->query($select);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }

        if ($select->rowCount() > 0) {
            $selectRes = $select->fetch(PDO::FETCH_ASSOC);

            $idGestor = $selectRes['z_sga_usuarios_id'];
        } else {
            return array('return' => false);
        }

        // Prepara as querys
        $delete = "DELETE FROM z_sga_gest_mpr_dtsul WHERE codProgDtsul = '$codPrograma'";
        $insert = "INSERT INTO z_sga_gest_mpr_dtsul (idUsuario, codMdlDtsul, codProgDtsul, codRotinaDtsul) VALUES ($idGestor, '$codModulo', '$codPrograma', '$codRotina')";

        // die($insert);

        // Executa
        try {
            $this->db->query($delete);
            $this->db->query($insert);

            return array('return' => true);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }
    }

    public function validaCadastroGestorRotina($codGestor, $codRotina)
    {
        // Variaveis
        $select = "";
        $insert = "";
        $delete = "";
        $idGestor = 0;
        $selectRes = array();

        // Verifica se a rotina existe
        $select = "
            SELECT
                codigo_rotina
            FROM
                z_sga_programas
            WHERE
                codigo_rotina = '$codRotina'
        ";

        // Tenta executar o select
        try {
            $select = $this->db->query($select);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }

        if ($select->rowCount() < 1) {
            return array('return' => false);
        }


        // Verifica se o gestor existe
        $select = "
            SELECT
                z_sga_usuarios_id
            FROM
                z_sga_usuarios
            WHERE
                cod_usuario = '$codGestor'
        ";

        // Tenta executar o select
        try {
            $select = $this->db->query($select);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }

        if ($select->rowCount() > 0) {
            $selectRes = $select->fetch(PDO::FETCH_ASSOC);

            $idGestor = $selectRes['z_sga_usuarios_id'];
        }


        // Prepara as querys
        $delete = "DELETE FROM z_sga_gest_mpr_dtsul WHERE codProgDtsul = '*' AND codMdlDtSul = '*' AND codRotinaDtsul = '$codRotina'";
        $insert = "INSERT INTO z_sga_gest_mpr_dtsul (idUsuario, codMdlDtsul, codProgDtsul, codRotinaDtsul) VALUES ($idGestor, '*', '*', '$codRotina')";

        // die($insert);

        // Executa
        try {
            $this->db->query($delete);
            $this->db->query($insert);

            return array('return' => true);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }
    }

    public function validaCadastroGestorModulo($codGestor, $codModulo)
    {
        // Variaveis
        $select = "";
        $insert = "";
        $delete = "";
        $idGestor = 0;
        $selectRes = array();

        // Verifica se o modulo existe
        $select = "
            SELECT
                cod_modulo
            FROM
                z_sga_programas
            WHERE
                cod_modulo = '$codModulo'
        ";

        // Tenta executar o select
        try {
            $select = $this->db->query($select);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }

        if ($select->rowCount() < 1) {
            return array('return' => false);
        }


        // Verifica se o gestor existe
        $select = "
            SELECT
                z_sga_usuarios_id
            FROM
                z_sga_usuarios
            WHERE
                cod_usuario = '$codGestor'
        ";

        // Tenta executar o select
        try {
            $select = $this->db->query($select);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }

        if ($select->rowCount() > 0) {
            $selectRes = $select->fetch(PDO::FETCH_ASSOC);

            $idGestor = $selectRes['z_sga_usuarios_id'];
        }


        // Prepara as querys
        $delete = "DELETE FROM z_sga_gest_mpr_dtsul WHERE codProgDtsul = '*' AND codMdlDtSul = '$codModulo' AND codRotinaDtsul = '*'";
        $insert = "INSERT INTO z_sga_gest_mpr_dtsul (idUsuario, codMdlDtsul, codProgDtsul, codRotinaDtsul) VALUES ($idGestor, '$codModulo', '*', '*')";

        // die($insert);

        // Executa
        try {
            $this->db->query($delete);
            $this->db->query($insert);

            return array('return' => true);
        } catch (Exception $e) {
            return array('return' => false, 'message' => 'Ocorreu o seguinte erro: ', 'error' => $e->getMessage());
        }
    }
}