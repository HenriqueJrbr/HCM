<?php

class acesso_temporario extends regrasform{


}