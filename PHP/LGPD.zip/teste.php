<?php
    $var='abc';
?>