<style>
    h2 small{
        font-size: 13px;
        font-weight: bold;        
        color: #FF8000
    }
</style>

<div class="col-md-12 col-sm-12 col-xs-12">
    <ol class="breadcrumb">        
        <li class="active">Dashboard</li>
    </ol>
</div>
<div class="col-md-12 col-sm-12 col-xs-12">
 <div class="page-title">
    <div class="title_left">
    	<h3>Dashboard<small></small></h3>
    </div>
 </div>
</div>