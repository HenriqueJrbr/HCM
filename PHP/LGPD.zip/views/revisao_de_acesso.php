<form method="POST">
	<div class="x_panel">
		<div class="row">
			<div class="col-md-4">
				<input type="submit" class="btn btn-primary" name="iniciaRevisao" id="iniciaRevisao" value="Inicia Revisão">

			</div>
		</div>
	

		<div class="x_content">
	    
	        <table class="tabela table table-striped table-bordered dataTable no-footer" role="grid" aria-describedby="datatable_info">
	          <thead>
	            <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 158px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Nome</font></font></th><th class="sorting" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 259px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Posição</font></font></th><th class="sorting" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 117px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Escritório</font></font></th><th class="sorting" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 59px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Era</font></font></th><th class="sorting" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" aria-label="Start date: activate to sort column ascending" style="width: 117px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Data de início</font></font></th><th class="sorting" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 90px;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Salário</font></font></th></tr>
	          </thead>


	        	<tbody>
		             <tr role="row" class="odd">
		              <td class="sorting_1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Ashton Cox</font></font></td>
		              <td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Autor Técnico Júnior</font></font></td>
		              <td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">São Francisco</font></font></td>
		              <td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">66</font></font></td>
		              <td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2009/01/12</font></font></td>
		              <td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">US $ 86.000</font></font></td>
		            </tr>
	        	</tbody>

	        </table>            
		</div>
	</div>
</form>